#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "lcd.h"
#include "usart.h"	 
#include "24cxx.h"
#include "w25qxx.h"
#include "touch.h"

#include "AUDIO.h"
#include "sdio_sdcard.h"
#include "quicklz.h"

//#define DEBUG

/*
	ȫ�ֱ���
*/


//ģʽSample��Play��Cross���ֻ����һ��Ϊ1��InfoģʽһֱΪ1������ʾ
extern u8 Now_Mode[4];
extern u8 Info_Mode[3];

extern u8 Now_ADC;

extern u8 ADC_BUFF[TF_DATA_SISE];
extern u8 DAC_BUFF[TF_DATA_SISE];

extern u8 ADC_FINISH_FLAG;
extern u8 DAC_FINISH_FLAG;

extern u16 TF_Page_Count;
extern u16 TF_End_Page;

extern u16 Last_Count;

extern u16 time_count;

extern u8 QuickLZ_Flag;
	
qlz_state_compress state_compress;
qlz_state_decompress state_decompress;
extern size_t QuickLZ_Size ;

extern u8 SINC_Flag;

int main(void)
{
	u16 i=0;
#ifdef DEBUG
	u16 time1,time2;
#endif
	u8 DATA_BUFF[TF_DATA_SISE];
	char str[7] = {0};
	
	delay_init();	    	 //��ʱ������ʼ��	  
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 	 //����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	uart_init(115200);	 	//���ڳ�ʼ��Ϊ9600
 	LED_Init();			     //LED�˿ڳ�ʼ��
	LCD_Init();	
	KEY_Init();
	W25QXX_Init();
 	tp_dev.init();
	
	
	TIM2_Int_Init(65535,71);//��1usΪ��λ�����Դ�������ʱ��
	TIM3_Int_Init(TIM_ARR,TIM_PSC);
	TIM4_Int_Init(SINC_ARR,SINC_PSC);//16KHz
	ADC_FX_Init();
	DAC_FX_Init();
	
	while(SD_Init())//��ⲻ��SD��
	{
		LCD_ShowString(30,150,200,16,16,(u8*)"SD Card Error!");
		delay_ms(500);
		LCD_ShowString(30,150,200,16,16,(u8*)"Please Check! ");
		delay_ms(500);
		LED0=!LED0;//DS0��˸
	}
	


#ifdef DEBUG
	
	/*-------------------TF����д�ٶȲ���-------------------*/
	time1 = TIM_GetCounter(TIM2);
	SD_WriteDisk(DATA_BUFF,1,1);
	time2 = TIM_GetCounter(TIM2);
	printf("\r\n SD Write Disk one Page time : %d us\r\n ",time2-time1);
	
	time1 = TIM_GetCounter(TIM2);
	SD_ReadDisk(DATA_BUFF,1,1);
	time2 = TIM_GetCounter(TIM2);
	printf("\r\n SD Read Disk one Page time : %d us\r\n ",time2-time1);
	
	/*--------------QuickLZѹ���㷨����------------------*/
	printf("\r\n/*--------------QuickLZѹ���㷨����------------------*/\r\n ");
	
	//����ռ�õ���Դ�ռ��С
	printf("\r\n u8 size : %d \r\n ", sizeof(u8) );
	printf("\r\n u16 size : %d \r\n ", sizeof(u16) );
	printf("\r\n u32 size : %d \r\n ", sizeof(u32) );
	printf("\r\n float size : %d \r\n ", sizeof(float) );
	printf("\r\n double size : %d \r\n ", sizeof(double) );
	printf("\r\n qlz_state_compress size : %d \r\n ", sizeof(qlz_state_compress) );
	printf("\r\n qlz_state_decompress size : %d \r\n ", sizeof(qlz_state_decompress) );
	
	//ѹ��ʱ�䡢ѹ���ʲ���
	SD_ReadDisk(DAC_BUFF,1,1);
	
	printf("\r\nbefore compress:\r\n ");
	for(i=0;i<512;i++)
		printf("%d ",DAC_BUFF[i]);
	
	time1 = TIM_GetCounter(TIM2);
	Quich_LZ_Size = qlz_compress(DAC_BUFF,(char*)ADC_BUFF,512, &state_compress);
	time2 = TIM_GetCounter(TIM2);
	printf("\r\ncompress time : %d us\r\n ",time2-time1);
	
	printf("\r\nAfter compress: Quich_LZ_Size = %d.\r\n ",Quich_LZ_Size);
	for(i=0;i<512;i++)
		printf("%d ",ADC_BUFF[i]);
	
	time1 = TIM_GetCounter(TIM2);
	Quich_LZ_Size = qlz_decompress((char*)ADC_BUFF, DAC_BUFF , &state_decompress);
	time2 = TIM_GetCounter(TIM2);
	printf("\r\ndecompress time : %d us\r\n ",time2-time1);
	
	printf("\r\nAfter decompress: Quich_LZ_Size = %d.\r\n ",Quich_LZ_Size);
	for(i=0;i<512;i++)
		printf("%d ",DAC_BUFF[i]);
	
#endif
	
	
	
	//��ʼ��UI����,���ⴥ��һ�½������
	MODE_Scan_DISP(0 , 300 );
	
	
	while(1)
	{
		tp_dev.scan(0);
		if(tp_dev.sta&TP_PRES_DOWN)			//������������
		{
		 	if(tp_dev.x[0]<lcddev.width&&tp_dev.y[0]<lcddev.height)
			{
				//ɨ�败��������ö�Ӧ�ĺ���
				switch (MODE_Scan_DISP( tp_dev.x[0] , tp_dev.y[0] ) )
				{
					case MODE_Sample:
					if(Now_Mode[0])
						MODE_Sample_ON_Function();
					else if( !Now_Mode[0] )
						MODE_Sample_OFF_Function();
					break;
					
					case MODE_Play:
					if(Now_Mode[1])
						MODE_Play_ON_Function();
					else if( !Now_Mode[1] )
						MODE_Play_OFF_Function();
					break;
					
					case MODE_Cross:
					if(Now_Mode[2])
						MODE_Cross_ON_Function();
					else if( !Now_Mode[2] )
						MODE_Cross_OFF_Function();
					break;
					
					case MODE_AVC:
					if(Info_Mode[0])
						INFO_AVC_Function_ON();
					else if( !Info_Mode[0] )
						INFO_AVC_Function_OFF();
					break;
					
					case MODE_QuickLZ:
					if(Info_Mode[1])
						INFO_QuickLZ_Function_ON();
					else if( !Info_Mode[1] )
						INFO_QuickLZ_Function_OFF();
					break;
					
					case MODE_SINC:
					if(Info_Mode[2])
						INFO_SINC_Function_ON();
					else if( !Info_Mode[2] )
						INFO_SINC_Function_OFF();
					break;
					
					default:break;
				}
			}
		}
		
		//д������Ƴ��ж�
		if(ADC_FINISH_FLAG)
		{
			ADC_FINISH_FLAG = 0;

			if( QuickLZ_Flag )
			{
				QuickLZ_Size = qlz_compress(ADC_BUFF,(char*)DATA_BUFF,512, &state_compress);
				SD_WriteDisk(DATA_BUFF,TF_Page_Count,1);
			}
			else
				SD_WriteDisk(ADC_BUFF,TF_Page_Count,1);
			
			TF_Page_Count++;
			time_count++;
			sprintf(str,"%7.1f",(float)time_count*0.064);
			LCD_ShowString(40+MODE_Str_Size*2,MODE_Info_DISP_Range_Start+MODE_Str_Size*5,MODE_Str_Size*7, MODE_Str_Size, MODE_Str_Size,(u8*)str);
			
		}
		
		//���������Ƴ��ж�
		if(DAC_FINISH_FLAG)
		{
			DAC_FINISH_FLAG = 0;
			
			if( QuickLZ_Flag )
			{
				while(SD_ReadDisk(DATA_BUFF,TF_Page_Count,1)!=0);
				if(TF_Page_Count != TF_End_Page)
					qlz_decompress((char*)DATA_BUFF, DAC_BUFF , &state_decompress);
				else
					for(i=0;i<512;i++)
						DAC_BUFF[i] = DATA_BUFF[i];
			}
			else
				while(SD_ReadDisk(DAC_BUFF,TF_Page_Count,1)!=0);
			
			TF_Page_Count++;
			time_count++;
			sprintf(str,"%7.1f",(float)time_count*0.064);
			LCD_ShowString(40+MODE_Str_Size*2,MODE_Info_DISP_Range_Start+MODE_Str_Size*5,MODE_Str_Size*7, MODE_Str_Size, MODE_Str_Size,(u8*)str);
			
			if( TF_Page_Count > TF_End_Page )//������ϣ��Զ�������������
			{
				
				TIM_ITConfig(TIM3,TIM_IT_Update,DISABLE);
				TIM_ITConfig(TIM4,TIM_IT_Update,DISABLE);
				
				if(SINC_Flag)
					MODE_Scan_DISP( 200 , 250 );
				else
					MODE_Scan_DISP( 50 , 100 );

				INFO_SINC_Function_OFF();
				MODE_Play_OFF_Function();

			}
			
		}
		
		i++;
		if(i>=2000)
		{
			i=0;
			LED0=!LED0;
		}
		
	}
}







