#ifndef __AUDIO_H__
#define __AUDIO_H__

#include "sys.h"
#include "touch.h" 
#include "lcd.h"

//���嵱ǰ��ģʽ
#define MODE_Sample 		1
#define MODE_Play   		2
#define MODE_Cross  		3
#define MODE_AVC   			4
#define MODE_QuickLZ   	5
#define MODE_SINC   		6

//����ģʽ��ʾ��λ��
#define MODE_Sample_DISP_Range_Start 0
#define MODE_Play_DISP_Range_Start   80
#define MODE_Cross_DISP_Range_Start  160
#define MODE_Info_DISP_Range_Start   240

#define MODE_Sample_DISP_Range_End 69
#define MODE_Play_DISP_Range_End   149
#define MODE_Cross_DISP_Range_End  229
#define MODE_Info_DISP_Range_End   319

//����Infoģʽ��������ʾ��Ϣ
#define INFO_AVC_DISP_Range_Start 		5
#define INFO_QuickLZ_DISP_Range_Start 80
#define INFO_SINC_DISP_Range_Start 		160

#define INFO_AVC_DISP_Range_End 			75
#define INFO_QuickLZ_DISP_Range_End 	155
#define INFO_SINC_DISP_Range_End 			235

//������ʾ�������ɫ
#define MODE_Sample_DISP_ON  	RED
#define MODE_Sample_DISP_OFF 	GREEN

#define MODE_Play_DISP_ON  		YELLOW
#define MODE_Play_DISP_OFF 		GREEN

#define MODE_Cross_DISP_ON  	BLUE
#define MODE_Cross_DISP_OFF 	GREEN

#define MODE_Info_DISP_ON  		BLUE
#define MODE_Info_DISP_OFF  	GREEN

//����INFO�������ɫ
#define INFO_AVC_DISP_ON			RED
#define INFO_AVC_DISP_OFF			GREEN

#define INFO_QuickLZ_DISP_ON	YELLOW
#define INFO_QuickLZ_DISP_OFF	GREEN

#define INFO_SINC_DISP_ON			BLUE
#define INFO_SINC_DISP_OFF		GREEN

//����������ʾ��Ϣ
#define MODE_Str_Size  12
#define MODE_Str_Width   MODE_Str_Size * 9

#define MODE_Sample_Str (u8*)"Sample ON"
#define MODE_Play_Str 	(u8*)"Play   ON"
#define MODE_Cross_Str 	(u8*)"Cross  ON"
#define MODE_Info_Str 	(u8*)"Info   ON"

#define MODE_Sample_Str_OFF (u8*)"Sample OFF"
#define MODE_Play_Str_OFF 	(u8*)"Play   OFF"
#define MODE_Cross_Str_OFF 	(u8*)"Cross  OFF"
#define MODE_Info_Str_OFF 	(u8*)"Info   OFF"

#define INFO_Str_Size  12
#define INFO_Str_Width   INFO_Str_Size * 10

#define INFO_AVC_Str 					(u8*)"AVC     ON"
#define INFO_QuickLZ_Str 			(u8*)"QuickLZ ON"
#define INFO_SINC_Str 				(u8*)"SINC    ON"

#define INFO_AVC_Str_OFF 			(u8*)"AVC     OFF"
#define INFO_QuickLZ_Str_OFF 	(u8*)"QuickLZ OFF"
#define INFO_SINC_Str_OFF 	  (u8*)"SINC    OFF"

//�����Զ���������ʱ��Ŀ�깦�ʲ���
#define AVC_Average_Vol			128

#define AVC_Det							10		//300mv
//#define AVC_Det							20		//300mv
//#define AVC_Det						30		//400mv

#define AVC_MAX_Power				2212.500000
#define AVC_Average_Power		(AVC_MAX_Power*4/5)

#define SNR_Count_Gate		500


//��ʱ���ж�ʱ������ 8KHz
#define TIM_PSC 72-1
#define TIM_ARR 125-1

#define SINC_ARR 125-1
#define SINC_PSC 18-1

//����ADCת����ͨ��
#define ADC_CH ADC_Channel_2

//����д��TF���Ĵ�С
#define TF_DATA_SISE 512
#define Start_Char 192


/*��������*/
u8 MODE_Scan_DISP(u16 x , u16 y);

void MODE_Sample_ON_Function(void);
void MODE_Play_ON_Function(void);
void MODE_Cross_ON_Function(void);

void MODE_Sample_OFF_Function(void);
void MODE_Play_OFF_Function(void);
void MODE_Cross_OFF_Function(void);

void INFO_AVC_Function_ON(void);
void INFO_AVC_Function_OFF(void);
void INFO_QuickLZ_Function_ON(void);
void INFO_QuickLZ_Function_OFF(void);
void INFO_SINC_Function_ON(void);
void INFO_SINC_Function_OFF(void);

void TIM2_Int_Init(u16 arr,u16 psc);
void TIM3_Int_Init(u16 arr,u16 psc);
void TIM4_Int_Init(u16 arr,u16 psc);
void ADC_FX_Init(void);
void DAC_FX_Init(void);
void Disp_Info(void);



#endif

















